Unzip at repo root. Keep .nojekyll at top-level.
